# api.py

import sqlite3
import os
import threading
import re
from datetime import datetime
from dotenv import load_dotenv
from flask import Flask, jsonify, request
from flask_cors import CORS

# --- Imports for Scheduling ---
from apscheduler.schedulers.background import BackgroundScheduler
import pytz

# --- Imports for AI Agents & Pipeline ---
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from pydantic.v1 import BaseModel, Field, ValidationError
from typing import List
import pipeline # The module containing the core logic
import database # Import database to access config functions

# --- Configuration ---
DB_NAME = 'news_data.db'
load_dotenv()
PIPELINE_PASSWORD = os.getenv("PIPELINE_PASSWORD")

# --- Global State for Pipeline Tracking ---
pipeline_status_tracker = {
    "is_running": False,
    "status": "Idle",
    "progress": 0,
    "total": 0,
    "current_task": "N/A"
}

# --- Flask App Initialization ---
app = Flask(__name__)
CORS(app)

# --- Database Helper Function ---
def get_db_connection():
    """Creates a database connection that returns dictionary-like rows."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

# --- Summarization Agent Setup ---
class Summary(BaseModel):
    """A structured summary of an entity's sentiment profile."""
    positive_financial: List[str] = Field(description="A list of key positive points related to financial performance.")
    negative_financial: List[str] = Field(description="A list of key negative points related to financial performance.")
    neutral_financial: List[str] = Field(description="A list of key neutral points or factual statements related to financial performance.")
    positive_overall: List[str] = Field(description="A list of key positive points related to general operations, products, and decisions.")
    negative_overall: List[str] = Field(description="A list of key negative points related to general operations, products, and decisions.")
    neutral_overall: List[str] = Field(description="A list of key neutral points or factual statements related to general operations.")
    final_summary: str = Field(description="A brief, conclusive summary of the entity's overall position based on the provided reasons.")

try:
    summary_llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    structured_summary_llm = summary_llm.with_structured_output(Summary)
except Exception as e:
    print(f"Warning: Could not initialize summarization LLM. The /summarize_entity endpoint will not work. Error: {e}")
    structured_summary_llm = None

summary_prompt_template = ChatPromptTemplate.from_messages([
    ("system", """
You are an expert financial analyst. You will be given a list of reasoning snippets from multiple news articles about a specific company or cryptocurrency. Your task is to synthesize these snippets into a clear, structured summary.

Analyze all the provided reasons and categorize the key points into six lists:
1.  **Positive Financial:** Reasons related to stock growth, good earnings, etc.
2.  **Negative Financial:** Reasons related to stock decline, poor earnings, etc.
3.  **Neutral Financial:** Factual financial statements without clear positive or negative sentiment.
4.  **Positive Overall:** Reasons related to successful products, partnerships, good decisions, etc.
5.  **Negative Overall:** Reasons related to failed projects, legal issues, poor decisions, etc.
6.  **Neutral Overall:** Factual statements about operations, announcements, or collaborations without clear positive or negative sentiment.

Finally, provide a brief, one or two-sentence `final_summary` of the entity's overall position based on the balance of the points.

Do not invent new information. Base your summary *only* on the provided reasoning snippets. It is critical that your final JSON object includes all fields, especially `final_summary`.
"""),
    ("human", "Please summarize the following reasoning points for {entity_name}:\n\n{reasoning_list}")
])

if structured_summary_llm:
    summary_chain = summary_prompt_template | structured_summary_llm
else:
    summary_chain = None


# --- API Endpoints ---

@app.route('/')
def home():
    """A simple welcome message and guide for the API root."""
    return jsonify({
        "message": "Welcome to the Financial News Sentiment API.",
        "endpoints": {
            "/api/trigger_pipeline": {
                "method": "POST",
                "description": "Starts the scraping and analysis process in the background. Requires password.",
                "body_example": {"password": "your_password", "provider": "openai", "model_name": "gpt-4-turbo"}
            },
            "/api/configure_schedule": {
                "method": "POST",
                "description": "Sets the daily UTC time for the automated pipeline run. Requires password.",
                "body_example": {"password": "your_password", "schedule_time": "02:30"}
            },
            "/api/pipeline_status": {
                "method": "GET",
                "description": "Returns the real-time status of the currently running pipeline."
            },
            "/api/pipeline_last_run": {
                "method": "GET",
                "description": "Returns the statistics from the most recently completed pipeline run."
            },
            "/api/articles": {
                "method": "GET",
                "description": "Get and filter articles with sentiment data.",
                "params": ["limit", "entity_name", "entity_type", "financial_sentiment", "overall_sentiment"]
            },
            "/api/entities": {
                "method": "GET",
                "description": "Get a list of all unique entities."
            },
            "/api/top_entities": {
                "method": "GET",
                "description": "Get top entities ranked by sentiment count.",
                "params": ["sentiment_type (financial or overall)", "sentiment (positive, negative, neutral)", "order (asc or desc)", "limit"]
            },
            "/api/sentiment_over_time": {
                "method": "GET",
                "description": "Get an entity's sentiment trend over time, formatted for graphing.",
                "params": ["entity_name"]
            },
            "/api/summarize_entity": {
                "method": "GET",
                "description": "Get an AI-generated summary for a specific company or crypto.",
                "params": ["entity_name"]
            },
            "/api/entity_articles_by_sentiment": {
                "method": "GET",
                "description": "Get articles for an entity, grouped by sentiment categories.",
                "params": ["entity_name", "entity_type"]
            },
             "/api/usage_stats": {
                "method": "GET",
                "description": "Get API usage and cost statistics.",
                "params": ["summarize=true"]
            }
        }
    })

@app.route('/api/trigger_pipeline', methods=['POST'])
def trigger_pipeline():
    """Triggers the full data pipeline to run in the background. Requires a password."""
    if pipeline_status_tracker["is_running"]:
        return jsonify({"error": "A pipeline is already running."}), 409

    data = request.get_json(silent=True) or {}
    password = data.get("password")

    if not password or password != PIPELINE_PASSWORD:
        return jsonify({"error": "Unauthorized. A valid password is required."}), 401
    
    config = {
        "provider": data.get("provider"),
        "model_name": data.get("model_name"),
        "openai_api_key": data.get("openai_api_key"),
        "groq_api_key": data.get("groq_api_key")
    }

    def pipeline_task(app_context, config):
        with app_context:
            pipeline_status_tracker["is_running"] = True
            try:
                scraping_stats = pipeline.run_scraping_pipeline(pipeline_status_tracker)
                analysis_stats = pipeline.run_analysis_pipeline(pipeline_status_tracker, **config)
                final_stats = {**scraping_stats, **analysis_stats, "status": "Completed"}
                database.add_pipeline_run(final_stats)
            except Exception as e:
                print(f"Pipeline failed: {e}")
                database.add_pipeline_run({"status": f"Failed: {e}"})
            finally:
                pipeline_status_tracker["is_running"] = False
                pipeline_status_tracker["status"] = "Idle"
                pipeline_status_tracker["progress"] = 0
                pipeline_status_tracker["total"] = 0
                pipeline_status_tracker["current_task"] = "N/A"

    thread = threading.Thread(target=pipeline_task, args=(app.app_context(), config))
    thread.daemon = True
    thread.start()

    return jsonify({"message": "Pipeline triggered successfully. It will run in the background."}), 202

@app.route('/api/configure_schedule', methods=['POST'])
def configure_schedule():
    """Sets the daily UTC time for the automated pipeline run. Requires a password."""
    data = request.get_json(silent=True) or {}
    password = data.get("password")
    new_time = data.get("schedule_time")

    if not password or password != PIPELINE_PASSWORD:
        return jsonify({"error": "Unauthorized. A valid password is required."}), 401

    if not new_time or not re.match(r'^([01]\d|2[0-3]):([0-5]\d)$', new_time):
        return jsonify({"error": "Invalid time format. Please use 'HH:MM'."}), 400

    try:
        hour, minute = map(int, new_time.split(':'))
        database.set_config_value('schedule_time', new_time)
        scheduler.reschedule_job('daily_pipeline_job', trigger='cron', hour=hour, minute=minute, timezone='utc')
        return jsonify({"message": f"Pipeline schedule updated successfully to {new_time} UTC."})
    except Exception as e:
        return jsonify({"error": "Failed to update schedule.", "details": str(e)}), 500

@app.route('/api/pipeline_status', methods=['GET'])
def get_pipeline_status():
    """Returns the real-time status of the currently running pipeline."""
    return jsonify(pipeline_status_tracker)

@app.route('/api/pipeline_last_run', methods=['GET'])
def get_last_run_stats():
    """Returns the statistics from the most recently completed pipeline run."""
    conn = get_db_connection()
    last_run = conn.execute("SELECT * FROM pipeline_runs ORDER BY run_timestamp DESC LIMIT 1").fetchone()
    conn.close()
    if last_run:
        return jsonify(dict(last_run))
    else:
        return jsonify({"message": "No previous pipeline run found."}), 404

@app.route('/api/top_entities', methods=['GET'])
def get_top_entities():
    """Returns a ranked list of entities based on the count of a specific sentiment."""
    sentiment_type = request.args.get('sentiment_type', 'overall')
    sentiment = request.args.get('sentiment', 'positive')
    order = request.args.get('order', 'desc')
    limit = request.args.get('limit', 10, type=int)

    if sentiment_type not in ['financial', 'overall'] or sentiment not in ['positive', 'negative', 'neutral'] or order.upper() not in ['ASC', 'DESC']:
        return jsonify({"error": "Invalid query parameters."}), 400

    sentiment_column = f"{sentiment_type}_sentiment"
    conn = get_db_connection()
    query = f"SELECT entity_name, entity_type, COUNT(*) as sentiment_count FROM sentiments WHERE {sentiment_column} = ? GROUP BY entity_name, entity_type ORDER BY sentiment_count {order} LIMIT ?"
    rows = conn.execute(query, (sentiment, limit)).fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])

@app.route('/api/sentiment_over_time', methods=['GET'])
def get_sentiment_over_time():
    """For a given entity, returns its sentiment scores over time, formatted for graphing."""
    entity_name = request.args.get('entity_name')
    if not entity_name: return jsonify({"error": "An 'entity_name' query parameter is required."}), 400
    conn = get_db_connection()
    query = "SELECT a.publication_date, s.financial_sentiment, s.overall_sentiment FROM sentiments s JOIN articles a ON s.article_id = a.id WHERE s.entity_name LIKE ? ORDER BY a.publication_date ASC"
    rows = conn.execute(query, (f"%{entity_name}%",)).fetchall()
    conn.close()
    if not rows: return jsonify({"error": f"No sentiment data found for entity: {entity_name}"}), 404
    def get_score(sentiment): return 1 if sentiment == 'positive' else -1 if sentiment == 'negative' else 0
    financial_trend = [[row['publication_date'], get_score(row['financial_sentiment'])] for row in rows]
    overall_trend = [[row['publication_date'], get_score(row['overall_sentiment'])] for row in rows]
    return jsonify({"entity_name": entity_name, "financial_sentiment_trend": financial_trend, "overall_sentiment_trend": overall_trend})

@app.route('/api/entity_articles_by_sentiment', methods=['GET'])
def get_entity_articles_by_sentiment():
    """For a given entity, returns a structured list of its associated articles, grouped by sentiment."""
    entity_name = request.args.get('entity_name')
    entity_type = request.args.get('entity_type')
    if not entity_name or not entity_type: return jsonify({"error": "Both 'entity_name' and 'entity_type' query parameters are required."}), 400
    conn = get_db_connection()
    query = "SELECT a.title, a.url, s.reasoning, s.financial_sentiment, s.overall_sentiment FROM sentiments s JOIN articles a ON s.article_id = a.id WHERE s.entity_name LIKE ? AND s.entity_type = ?"
    rows = conn.execute(query, (f"%{entity_name}%", entity_type)).fetchall()
    conn.close()
    if not rows: return jsonify({"error": f"No articles found for entity '{entity_name}' of type '{entity_type}'"}), 404
    response_data = {"positive_financial": [], "negative_financial": [], "neutral_financial": [], "positive_overall": [], "negative_overall": [], "neutral_overall": []}
    for row in rows:
        article_info = {"title": row['title'], "url": row['url'], "reasoning": row['reasoning']}
        if row['financial_sentiment'] == 'positive': response_data["positive_financial"].append(article_info)
        elif row['financial_sentiment'] == 'negative': response_data["negative_financial"].append(article_info)
        else: response_data["neutral_financial"].append(article_info)
        if row['overall_sentiment'] == 'positive': response_data["positive_overall"].append(article_info)
        elif row['overall_sentiment'] == 'negative': response_data["negative_overall"].append(article_info)
        else: response_data["neutral_overall"].append(article_info)
    for key in response_data:
        response_data[key] = [dict(t) for t in {tuple(d.items()) for d in response_data[key]}]
    return jsonify(response_data)

@app.route('/api/summarize_entity', methods=['GET'])
def summarize_entity():
    """Takes an entity name and uses an AI agent to generate a structured summary."""
    entity_name = request.args.get('entity_name')
    if not entity_name: return jsonify({"error": "An 'entity_name' query parameter is required."}), 400
    conn = get_db_connection()
    reasonings = conn.execute("SELECT reasoning, financial_sentiment, overall_sentiment FROM sentiments WHERE entity_name LIKE ?", (f"%{entity_name}%",)).fetchall()
    conn.close()
    if not reasonings: return jsonify({"error": f"No sentiment data found for entity: {entity_name}"}), 404
    reasoning_list_str = "\n".join([f"- (Financial: {r['financial_sentiment']}, Overall: {r['overall_sentiment']}) {r['reasoning']}" for r in reasonings])
    if not summary_chain: return jsonify({"error": "Summarization agent is not available."}), 503
    for attempt in range(3):
        try:
            summary_response = summary_chain.invoke({"entity_name": entity_name, "reasoning_list": reasoning_list_str})
            return jsonify(summary_response.dict())
        except ValidationError as e:
            if attempt >= 2: return jsonify({"error": "Failed to generate a valid summary after multiple attempts.", "details": str(e)}), 500
    return jsonify({"error": "Failed to generate summary."}), 500

@app.route('/api/articles', methods=['GET'])
def get_articles():
    """The main endpoint for fetching and filtering articles."""
    conn = get_db_connection()
    query = "SELECT a.id as article_id, a.title, a.url, a.author, a.publication_date, a.cleaned_text, s.id as sentiment_id, s.entity_name, s.entity_type, s.financial_sentiment, s.overall_sentiment, s.reasoning FROM articles a LEFT JOIN sentiments s ON a.id = s.article_id"
    conditions, params = [], {}
    if request.args.get('entity_name'): conditions.append("s.entity_name LIKE :entity_name"); params['entity_name'] = f"%{request.args.get('entity_name')}%"
    if request.args.get('entity_type'): conditions.append("s.entity_type = :entity_type"); params['entity_type'] = request.args.get('entity_type')
    if request.args.get('financial_sentiment'): conditions.append("s.financial_sentiment = :financial_sentiment"); params['financial_sentiment'] = request.args.get('financial_sentiment')
    if request.args.get('overall_sentiment'): conditions.append("s.overall_sentiment = :overall_sentiment"); params['overall_sentiment'] = request.args.get('overall_sentiment')
    if conditions: query += f" WHERE a.id IN (SELECT DISTINCT article_id FROM sentiments WHERE {' AND '.join(conditions)})"
    query += " ORDER BY a.publication_date DESC"
    limit = request.args.get('limit', 5, type=int)
    rows = conn.execute(query, params).fetchall()
    conn.close()
    articles = {}
    for row in rows:
        article_id = row['article_id']
        if article_id not in articles: articles[article_id] = {"id": article_id, "title": row['title'], "url": row['url'], "author": row['author'], "publication_date": row['publication_date'], "cleaned_text": row['cleaned_text'], "sentiments": []}
        if row['sentiment_id']: articles[article_id]['sentiments'].append({"entity_name": row['entity_name'], "entity_type": row['entity_type'], "financial_sentiment": row['financial_sentiment'], "overall_sentiment": row['overall_sentiment'], "reasoning": row['reasoning']})
    return jsonify(list(articles.values())[:limit])

@app.route('/api/entities', methods=['GET'])
def get_entities():
    """Returns a list of all unique entities found."""
    conn = get_db_connection()
    entities = conn.execute("SELECT DISTINCT entity_name, entity_type FROM sentiments ORDER BY entity_name").fetchall()
    conn.close()
    return jsonify([dict(row) for row in entities])

@app.route('/api/usage_stats', methods=['GET'])
def get_usage_stats():
    """Returns API usage and cost statistics."""
    summarize = request.args.get('summarize', 'false').lower() == 'true'
    conn = get_db_connection()
    if summarize: query = "SELECT provider, COUNT(*) as total_calls, SUM(total_tokens) as total_tokens, SUM(total_cost_usd) as total_cost FROM usage_logs GROUP BY provider"
    else: query = "SELECT * FROM usage_logs ORDER BY timestamp DESC"
    stats = conn.execute(query).fetchall()
    conn.close()
    return jsonify([dict(row) for row in stats])


# --- Scheduler Setup ---
def scheduled_pipeline_run():
    """A wrapper function for the scheduler to run the pipeline."""
    with app.app_context():
        print(f"--- Scheduled pipeline run started at {datetime.now(pytz.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC ---")
        if pipeline_status_tracker["is_running"]:
            print("Scheduled run skipped: A pipeline is already in progress.")
            return
        
        pipeline_status_tracker["is_running"] = True
        try:
            scraping_stats = pipeline.run_scraping_pipeline(pipeline_status_tracker)
            analysis_stats = pipeline.run_analysis_pipeline(pipeline_status_tracker)
            final_stats = {**scraping_stats, **analysis_stats, "status": "Completed"}
            database.add_pipeline_run(final_stats)
        except Exception as e:
            print(f"Scheduled pipeline failed: {e}")
            database.add_pipeline_run({"status": f"Failed: {e}"})
        finally:
            pipeline_status_tracker["is_running"] = False
            pipeline_status_tracker["status"] = "Idle"
            pipeline_status_tracker["progress"] = 0
            pipeline_status_tracker["total"] = 0
            pipeline_status_tracker["current_task"] = "N/A"

scheduler = BackgroundScheduler(daemon=True)

# --- Main Execution ---
if __name__ == '__main__':
    database.create_database()
    schedule_time_str = database.get_config_value('schedule_time', '01:00')
    hour, minute = map(int, schedule_time_str.split(':'))
    scheduler.add_job(scheduled_pipeline_run, 'cron', hour=hour, minute=minute, timezone='utc', id='daily_pipeline_job')
    scheduler.start()
    print(f"Pipeline scheduler started. Next run scheduled for {schedule_time_str} UTC daily.")
    app.run(debug=True, use_reloader=False)
